//
//  iOS_Final_ProjectTests.m
//  iOS Final ProjectTests
//
//  Created by Scott Jones on 4/28/14.
//  Copyright (c) 2014 Scott Jones. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface iOS_Final_ProjectTests : XCTestCase

@end

@implementation iOS_Final_ProjectTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
