//
//  RestaurantViewController.h
//  iOS Final Project
//
//  Created by Scott Jones on 5/5/14.
//  Copyright (c) 2014 Scott Jones. All rights reserved.
//

#import "ViewController.h"

@interface RestaurantViewController : ViewController

@end
