//
//  main.m
//  iOS Final Project
//
//  Created by Scott Jones on 4/28/14.
//  Copyright (c) 2014 Scott Jones. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
