//
//  ListViewController.m
//  iOS Final Project
//
//  Created by Scott Jones on 5/5/14.
//  Copyright (c) 2014 Scott Jones. All rights reserved.
//

#import "ListViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ListViewController ()
{
    CLLocationManager *_lm;
}

@property (weak, nonatomic) MKMapView *mapView;

@end

@implementation ListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _lm = [[CLLocationManager alloc] init];
    _lm.desiredAccuracy = kCLLocationAccuracyBest;
    _lm.distanceFilter = 10;
    _lm.delegate = self;
    _lm.headingFilter = 5;
    [_lm startUpdatingLocation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
